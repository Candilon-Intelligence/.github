#!/usr/bin/env bash
# Starts the model runtime and the AI plane (API + UI) on port 8081.
set -e
ROOT=$(cd "$(dirname "$0")/.." && pwd)
LOG=/tmp/candilon-ai-logs; mkdir -p $LOG
bash "$(dirname "$0")/stop_ai_colab.sh" >/dev/null 2>&1 || true

# layout the app expects (same as the Docker image)
mkdir -p /app "$ROOT/state"
ln -sfn "$ROOT/ai/core.py" /app/core.py; ln -sfn "$ROOT/ai/main.py" /app/main.py
ln -sfn "$ROOT/ai/ui" /app/ui; ln -sfn "$ROOT/config" /app/config; ln -sfn "$ROOT/state" /app/state
# approved data: data-plane output if it runs in this session, else a Drive folder you drop approved files into
APPROVED=/content/drive/MyDrive/candilon-approved
[ -d /content/candilon/data/approved ] && APPROVED=/content/candilon/data/approved
mkdir -p "$APPROVED"; ln -sfn "$APPROVED" /approved

# model runtime: at most 2 models in memory, idle ones unload (sleep)
export OLLAMA_MODELS=${OLLAMA_MODELS:-/content/ollama-models}
export OLLAMA_MAX_LOADED_MODELS=${OLLAMA_MAX_LOADED_MODELS:-2}
export OLLAMA_KEEP_ALIVE=${OLLAMA_KEEP_ALIVE:-2m}
export OLLAMA_NUM_PARALLEL=1 OLLAMA_HOST=127.0.0.1:11434
mkdir -p "$OLLAMA_MODELS"
nohup ollama serve > $LOG/ollama.log 2>&1 &
for i in $(seq 1 30); do curl -sf http://127.0.0.1:11434/api/tags >/dev/null && break; sleep 1; done

cd /app
OLLAMA_URL=http://127.0.0.1:11434 CANDILON_MODELS_CONFIG="$ROOT/config/models.colab.yaml" \
  nohup python -m uvicorn main:app --host 0.0.0.0 --port 8081 > $LOG/api.log 2>&1 &
for i in $(seq 1 40); do
  curl -sf http://127.0.0.1:8081/health >/dev/null && { echo "Candilon AI is up on port 8081. Approved folder: $APPROVED"; exit 0; }
  sleep 1
done
echo "Did not start. Logs:"; tail -n 20 $LOG/*.log; exit 1
