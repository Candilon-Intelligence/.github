#!/usr/bin/env bash
# Usage: bash pull_models.sh [model ...]   Default: the three models used by config/models.colab.yaml
export OLLAMA_MODELS=${OLLAMA_MODELS:-/content/ollama-models}
MODELS=("$@"); [ ${#MODELS[@]} -eq 0 ] && MODELS=(gemma2:2b llama3.2:3b qwen3.5:4b)
for m in "${MODELS[@]}"; do echo "Pulling $m ..."; ollama pull "$m" || echo "Could not pull $m (check the name at ollama.com/library)"; done
ollama list
