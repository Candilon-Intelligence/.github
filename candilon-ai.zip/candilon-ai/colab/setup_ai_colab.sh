#!/usr/bin/env bash
# Run ONCE per Colab session. Colab cannot run Docker, so the AI plane runs as plain processes.
set -e
export DEBIAN_FRONTEND=noninteractive
echo "[1/2] Installing Ollama (model runtime)..."
apt-get -qq update && apt-get -qq install -y zstd pciutils lshw >/dev/null
command -v ollama >/dev/null || curl -fsSL https://ollama.com/install.sh | sh
echo "[2/2] Python packages..."
pip -q install fastapi uvicorn httpx pandas pyyaml python-multipart
nvidia-smi -L 2>/dev/null || echo "No GPU detected: models will run on CPU and be slow. Use Runtime > Change runtime type > T4 GPU."
echo "Setup complete."
