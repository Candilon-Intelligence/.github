#!/usr/bin/env bash
pkill -f "uvicorn main:app" 2>/dev/null; pkill -f "ollama serve" 2>/dev/null; echo stopped
