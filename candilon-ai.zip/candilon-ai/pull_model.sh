#!/usr/bin/env bash
# Usage: ./pull_model.sh gemma2:2b   (downloads a model into ./models; works offline afterwards)
cd "$(dirname "$0")" && docker compose exec ollama ollama pull "${1:?model name, e.g. gemma2:2b}"
