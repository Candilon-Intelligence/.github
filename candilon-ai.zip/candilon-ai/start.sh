#!/usr/bin/env bash
# Starts the Candilon AI plane (models + RAG + UI). Run the data-plane stack separately (../candilon).
set -euo pipefail
cd "$(dirname "$0")"
command -v docker >/dev/null || { echo "Docker is not installed."; exit 1; }
docker info >/dev/null 2>&1 || { echo "Docker is not running. Start it and try again."; exit 1; }
mkdir -p state/no-approved
export APPROVED_DIR="${APPROVED_DIR:-$( [ -d ../candilon/data/approved ] && echo "$(cd ../candilon/data/approved && pwd)" || echo "$PWD/state/no-approved")}"
echo "Approved data folder: $APPROVED_DIR"
for try in 1 2 3 4 5; do
  docker compose build ai && break
  [ "$try" = 5 ] && { echo "Build failed 5 times. Check your internet and run ./start.sh again."; exit 1; }
  echo "Build failed (attempt $try of 5), retrying..."
done
docker compose up -d --wait
PORT=${CANDILON_AI_PORT:-8081}
echo; echo "Candilon AI is ready: http://localhost:${PORT}"
echo "No language model yet? Open the Models tab, or run: ./pull_model.sh gemma2:2b"
(command -v xdg-open >/dev/null && xdg-open "http://localhost:${PORT}") || (command -v open >/dev/null && open "http://localhost:${PORT}") || true
