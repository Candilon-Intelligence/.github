"""Candilon AI core: dataset store, BM25 retrieval, rule router, safe aggregate planner, verifier, provenance.
No web framework imports so it can be tested alone."""
import re, json, math, hashlib, sqlite3, time, pathlib, datetime, io, shutil
from collections import Counter
import pandas as pd

STATE = pathlib.Path("/app/state")
TOKEN = re.compile(r"[a-z0-9]+")
STOP = set("a an the of in on at for to and or is are was were be by with from as it this that what which who how many much do does did we our your their there than then into per each all any".split())
LANG = {"en": "English", "sw": "Swahili"}
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")
sha_bytes = lambda b: hashlib.sha256(b).hexdigest()


def toks(t):
    return [w for w in TOKEN.findall(str(t).lower()) if w not in STOP]


# ---------------- provenance (hash chain, SQLite) ----------------
def _db():
    STATE.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(STATE / "candilon_ai.db")
    c.execute("create table if not exists provenance(id integer primary key autoincrement, ts text, kind text, dataset_id text, detail text, prev_hash text, record_hash text)")
    return c


def prov_add(kind, ds, detail):
    c = _db()
    row = c.execute("select record_hash from provenance order by id desc limit 1").fetchone()
    prev, ts, d = (row[0] if row else "GENESIS"), now(), json.dumps(detail, sort_keys=True, default=str)
    h = hashlib.sha256("|".join([prev, ts, kind, ds, d]).encode()).hexdigest()
    c.execute("insert into provenance(ts,kind,dataset_id,detail,prev_hash,record_hash) values(?,?,?,?,?,?)", (ts, kind, ds, d, prev, h))
    c.commit(); c.close()
    return h


def prov_list(limit=100):
    c = _db()
    rows = c.execute("select id,ts,kind,dataset_id,detail,record_hash from provenance order by id desc limit ?", (limit,)).fetchall()
    c.close()
    return [{"id": r[0], "ts": r[1], "kind": r[2], "dataset_id": r[3], "detail": json.loads(r[4]), "record_hash": r[5]} for r in rows]


def prov_verify():
    c = _db()
    rows = c.execute("select id,ts,kind,dataset_id,detail,prev_hash,record_hash from provenance order by id").fetchall()
    c.close()
    prev = "GENESIS"
    for i, ts, k, ds, d, ph, rh in rows:
        if ph != prev or hashlib.sha256("|".join([prev, ts, k, ds, d]).encode()).hexdigest() != rh:
            return {"valid": False, "broken_at_record": i}
        prev = rh
    return {"valid": True, "records": len(rows)}


# ---------------- BM25 ----------------
class BM25:
    def __init__(self, docs, k1=1.5, b=0.75):
        self.docs, self.inv, self.len, self.k1, self.b = docs, {}, [], k1, b
        for i, d in enumerate(docs):
            c = Counter(toks(d["text"]))
            self.len.append(sum(c.values()))
            for t, f in c.items():
                self.inv.setdefault(t, []).append((i, f))
        self.n = len(docs)
        self.avg = (sum(self.len) / self.n) if self.n else 1

    def search(self, q, k=5):
        qt, scores = set(toks(q)), {}
        for t in qt:
            post = self.inv.get(t)
            if not post:
                continue
            idf = math.log(1 + (self.n - len(post) + 0.5) / (len(post) + 0.5))
            for i, f in post:
                scores[i] = scores.get(i, 0) + idf * f * (self.k1 + 1) / (f + self.k1 * (1 - self.b + self.b * self.len[i] / self.avg))
        top = sorted(scores.items(), key=lambda x: -x[1])[:k]
        return [(self.docs[i], s) for i, s in top], len(qt & set(self.inv)), len(qt)


# ---------------- datasets ----------------
class Dataset:
    def __init__(self, meta, df=None, docs=None):
        self.meta, self.df, self.cat, self.num = meta, df, {}, []
        self.docs = list(docs or [])
        if df is not None:
            for c in df.columns:
                if pd.api.types.is_numeric_dtype(df[c]):
                    self.num.append(c); continue
                u = df[c].dropna().astype(str).unique()
                if 0 < len(u) <= 200:
                    for v in u:
                        self.cat.setdefault(v.lower(), []).append((c, v))
            self.docs = [{"id": f"row-{i}", "text": self.rowtext(r)} for i, r in enumerate(df.head(200000).to_dict("records"))] + self.docs
        self.bm25 = BM25(self.docs)

    @staticmethod
    def rowtext(r):
        return "; ".join(f"{c}: {v}" for c, v in r.items() if pd.notna(v))


class Store:
    def __init__(self):
        self.ds = {}
        (STATE / "datasets").mkdir(parents=True, exist_ok=True)
        for d in sorted((STATE / "datasets").iterdir()):
            try:
                self.ds[d.name] = self._load(d)
            except Exception:
                pass

    def _load(self, d):
        meta = json.load(open(d / "meta.json"))
        if (d / "data.csv").exists():
            return Dataset(meta, df=pd.read_csv(d / "data.csv"))
        return Dataset(meta, docs=json.load(open(d / "docs.json")))

    def add(self, filename, raw, domain, source="upload", extra=None):
        sha = sha_bytes(raw)
        stem = re.sub(r"[^a-z0-9]+", "-", pathlib.Path(filename).stem.lower()).strip("-") or "data"
        did = f"{stem}-{sha[:8]}"
        d = STATE / "datasets" / did
        d.mkdir(parents=True, exist_ok=True)
        ext = pathlib.Path(filename).suffix.lower()
        meta = {"id": did, "name": filename, "domain": domain, "source": source, "sha256": sha, "verified": False, "created": now(), **(extra or {})}
        if ext == ".csv":
            (d / "data.csv").write_bytes(raw)
            df = pd.read_csv(io.BytesIO(raw))
            meta.update(kind="table", rows=len(df), columns=list(df.columns))
        elif ext in (".txt", ".md"):
            text = raw.decode("utf-8", errors="ignore")
            chunks = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
            json.dump([{"id": f"doc-{i}", "text": c[:1200]} for i, c in enumerate(chunks)], open(d / "docs.json", "w"))
            meta.update(kind="text", rows=len(chunks), columns=[])
        else:
            shutil.rmtree(d, ignore_errors=True)
            raise ValueError("Only .csv, .txt and .md files are supported")
        json.dump(meta, open(d / "meta.json", "w"))
        self.ds[did] = self._load(d)
        prov_add("dataset_added", did, {"name": filename, "sha256": sha, "source": source, "verified": meta["verified"], "rows": meta["rows"]})
        return meta

    def delete(self, did):
        self.ds.pop(did, None)
        shutil.rmtree(STATE / "datasets" / pathlib.Path(did).name, ignore_errors=True)
        prov_add("dataset_deleted", did, {})


def list_approved(root):
    out = []
    for p in sorted(pathlib.Path(root).glob("*.csv")):
        mf, info = p.with_suffix(".manifest.json"), {"filename": p.name, "verified": False}
        if mf.exists():
            try:
                m = json.load(open(mf))
                info.update(verified=m.get("sha256") == sha_bytes(p.read_bytes()), approver=m.get("approver"), approved_at=m.get("approved_at"))
            except Exception:
                pass
        out.append(info)
    return out


# ---------------- router ----------------
def route(question, ds, cfg):
    ql = question.lower()
    sw = len(set(TOKEN.findall(ql)) & set(cfg["router"]["swahili_words"]))
    lang = "sw" if sw >= 2 else "en"
    scores = {d: sum(1 for k in kws if k in ql) for d, kws in cfg["router"]["domains"].items()}
    prior = ds.meta.get("domain", "general")
    scores[prior] = scores.get(prior, 0) + 1.5
    domain = max(scores, key=scores.get) if any(scores.values()) else "general"
    sens = "high" if (domain in ("healthcare", "finance") or not ds.meta.get("verified", False)) else "medium"
    expert = "african-language" if lang != "en" else domain
    m = cfg["models"]
    return {"language": lang, "domain": domain, "sensitivity": sens, "rag_required": True, "deployment": "local",
            "expert": expert, "expert_model": m["experts"].get(expert, m.get("default_model"))}


# ---------------- safe aggregate planner (no free-form SQL) ----------------
OPS = [("percent", r"\b(percent|percentage|proportion|share|asilimia)\b|%"), ("mean", r"\b(average|mean|avg|wastani)\b"), ("median", r"\bmedian\b"),
       ("max", r"\b(maximum|max|highest|largest|longest|oldest)\b"), ("min", r"\b(minimum|min|lowest|smallest|shortest|youngest)\b"),
       ("top", r"\b(most common|most frequent|commonest|top)\b"), ("count", r"\b(how many|number of|count|total|wangapi|ngapi|idadi)\b")]


def _cols_in(text, cols):
    out = []
    for c in cols:
        words = [w for w in c.lower().split("_") if w not in ("of", "the", "id")] or [c.lower()]
        if all(re.search(rf"(?<![a-z0-9]){re.escape(w)}s?(?![a-z0-9])", text) for w in words):
            out.append((len(words), c))
    return [c for _, c in sorted(out, reverse=True)]


def make_plan(q, ds):
    if ds.df is None:
        return None
    ql, allc = q.lower(), list(ds.df.columns)
    op = next((o for o, p in OPS if re.search(p, ql)), None)
    gb, m = None, re.search(r"\b(?:by|per|for each|across)\s+([a-z_ ]+)", ql)
    if m:
        c = _cols_in(m.group(1), allc)
        gb = c[0] if c else None
    filters, used = [], []
    for v in sorted(ds.cat, key=len, reverse=True):
        if len(v) < 2:
            continue
        mm = re.search(rf"(?<![a-z0-9]){re.escape(v)}(?![a-z0-9])", ql)
        if mm and not any(mm.start() >= s and mm.end() <= e for s, e in used):
            filters.append(ds.cat[v][0]); used.append((mm.start(), mm.end()))
    col = None
    if op in ("mean", "median", "max", "min"):
        c = _cols_in(ql, ds.num)
        col = c[0] if c else (ds.num[0] if len(ds.num) == 1 else None)
        if col is None:
            return None
    if op == "top":
        catcols = {c for lst in ds.cat.values() for c, _ in lst}
        c = [x for x in _cols_in(ql, allc) if x in catcols]
        col = c[0] if c else None
        if col is None:
            return None
    if op is None and gb:
        op = "count"
    if op is None:
        return None
    return {"op": op, "column": col, "group_by": gb, "filters": filters}


def run_plan(ds, plan):
    df = ds.df
    mask = pd.Series(True, index=df.index)
    for c, v in plan["filters"]:
        mask &= df[c].astype(str).str.lower() == str(v).lower()
    sub, n, total = df[mask], int(mask.sum()), len(df)
    where = " AND ".join(f"{c} = {v}" for c, v in plan["filters"]) or "all records"
    op, col = plan["op"], plan["column"]
    if op == "count" and plan["group_by"]:
        g = sub.groupby(plan["group_by"]).size().sort_values(ascending=False).head(10)
        text = f"COUNT by {plan['group_by']} where {where}: " + ", ".join(f"{k} ({v})" for k, v in g.items())
    elif op == "count":
        text = f"COUNT of records where {where}: {n} (of {total} records)"
    elif op == "percent":
        text = f"PERCENT of records where {where}: {round(100 * n / total, 1) if total else 0.0}% ({n} of {total})"
    elif op in ("mean", "median", "max", "min"):
        s = pd.to_numeric(sub[col], errors="coerce").dropna()
        val = round(float(getattr(s, op)()), 2) if len(s) else None
        text = f"{op.upper()} of {col} where {where}: {val} (over {len(s)} records)"
    else:
        vc = sub[col].astype(str).value_counts().head(5)
        text = f"MOST COMMON {col} where {where}: " + ", ".join(f"{k} ({v})" for k, v in vc.items())
    samples = [(int(i), Dataset.rowtext(r)) for i, r in sub.head(3).iterrows()] if plan["filters"] and n else []
    return {"text": text, "matched": n, "samples": samples}


def retrieve(q, ds):
    plan = make_plan(q, ds)
    if plan:
        r = run_plan(ds, plan)
        ev = [{"id": "E1", "kind": "computed", "text": r["text"]}] + [{"id": f"E{i + 2}", "kind": "row", "ref": f"row-{ri}", "text": t} for i, (ri, t) in enumerate(r["samples"])]
        return {"task": "data_analysis", "plan": plan, "evidence": ev, "abstain": False, "template": f"{r['text']}. [E1]"}
    hits, matched, nq = ds.bm25.search(q, 5)
    if not hits or nq == 0 or matched / nq < 0.5:
        return {"task": "lookup", "plan": None, "evidence": [], "abstain": True, "template": ""}
    ev = [{"id": f"E{i + 1}", "kind": "passage", "ref": d["id"], "score": round(s, 2), "text": d["text"]} for i, (d, s) in enumerate(hits)]
    return {"task": "lookup", "plan": None, "evidence": ev, "abstain": False,
            "template": "Closest matching records: " + " ".join(f"[{e['id']}]" for e in ev[:3]) + " (no language model used)"}


# ---------------- generation + verification ----------------
def build_messages(q, ev, router):
    ctx = "\n".join(f"{e['id']}: {e['text']}" for e in ev)
    sys = (f"You are Candilon's {router['domain']} assistant. Answer ONLY from the EVIDENCE. Cite evidence ids like [E1]. "
           "Copy numbers exactly as written in the evidence. If the evidence does not answer the question, reply exactly: INSUFFICIENT EVIDENCE. "
           f"Reply in {LANG.get(router['language'], 'English')}. Be brief.")
    return [{"role": "system", "content": sys}, {"role": "user", "content": f"EVIDENCE:\n{ctx}\n\nQUESTION: {q}"}]


def _dec(s):
    return len(s.split(".")[1]) if "." in s else 0


def _num_ok(a, pool):
    for e in pool:
        try:
            if round(float(e), _dec(a)) == float(a):
                return True
        except ValueError:
            pass
    return False


def verify(answer, ev, question, computed=False, check_wording=True):
    a = answer.strip()
    if "insufficient evidence" in a.lower():
        return {"status": "ABSTAINED", "checks": [{"name": "Declined to answer without evidence", "ok": True}]}
    ev_text = " ".join(e["text"] for e in ev).lower().replace(",", "")
    pool = re.findall(r"\d+(?:\.\d+)?", ev_text) + re.findall(r"\d+(?:\.\d+)?", question.replace(",", ""))
    body = re.sub(r"\[E\d+\]", "", a).replace(",", "")
    nums = re.findall(r"\d+(?:\.\d+)?", body)
    bad = [n for n in nums if not _num_ok(n, pool)]
    ids, cited = {e["id"] for e in ev}, set(re.findall(r"\[(E\d+)\]", a))
    words = [w for w in TOKEN.findall(body.lower()) if len(w) > 3]
    overlap = (sum(1 for w in words if w in ev_text or w in question.lower()) / len(words)) if words else 1.0
    first = re.findall(r"\d+(?:\.\d+)?", ev[0]["text"].split(":", 1)[-1].replace(",", "")) if (computed and ev) else []
    checks = [{"name": "Every number appears in the evidence", "ok": not bad, "detail": ", ".join(bad)},
              {"name": "Citations point to real evidence", "ok": cited <= ids, "detail": ", ".join(sorted(cited - ids))},
              {"name": "Answer cites its evidence", "ok": bool(cited)}]
    if check_wording and not computed:
        checks.append({"name": "Wording is supported by the evidence", "ok": overlap >= 0.4, "detail": f"{overlap:.0%}"})
    if computed:
        checks.append({"name": "States the computed value", "ok": bool(first) and _num_ok(first[0], nums) or (first[:1] and first[0] in nums)})
    hard_names = ("Every number appears in the evidence", "Citations point to real evidence", "States the computed value")
    hard = any(not c["ok"] for c in checks if c["name"] in hard_names)
    return {"status": "UNSUPPORTED" if hard else ("PARTIAL" if any(not c["ok"] for c in checks) else "GROUNDED"), "checks": checks}


def pick_model(expert_model, installed, cfg):
    inst = {m.replace(":latest", "") for m in installed}
    for m in [expert_model] + cfg["models"].get("fallbacks", []):
        if m and m.replace(":latest", "") in inst:
            return m.replace(":latest", "")
    return sorted(inst)[0] if inst else None


def ask(question, ds, cfg, llm=None, installed=()):
    t0 = time.time()
    r = route(question, ds, cfg)
    ev = retrieve(question, ds)
    r["task"] = ev["task"]
    computed, note, model = bool(ev["plan"]), "", None
    if ev["abstain"]:
        answer = "INSUFFICIENT EVIDENCE: nothing in the approved data matches this question."
    else:
        answer = None
        model = pick_model(r["expert_model"], installed, cfg) if llm else None
        if model:
            try:
                answer = llm(build_messages(question, ev["evidence"], r), model)
            except Exception as e:
                note = f"Model call failed ({str(e)[:80]}); showing the computed answer."
        elif llm:
            note = "No model installed yet; showing the computed answer. Add one in the Models tab."
        if not answer:
            answer, model = ev["template"], None
    ver = verify(answer, ev["evidence"], question, computed, check_wording=bool(model))
    if ver["status"] == "UNSUPPORTED" and ev["template"] and model:
        note = "The model's answer failed verification and was replaced by the computed answer."
        answer, model = ev["template"], None
        ver = verify(answer, ev["evidence"], question, computed, check_wording=False)
    h = prov_add("query", ds.meta["id"], {"question": question[:300], "router": r, "model": model, "evidence_ids": [e.get("ref", e["id"]) for e in ev["evidence"]],
                 "plan": ev["plan"], "verification": ver["status"], "answer_sha256": sha_bytes(answer.encode()), "dataset_sha256": ds.meta["sha256"]})
    return {"question": question, "router": r, "plan": ev["plan"], "evidence": ev["evidence"], "answer": answer, "model": model, "note": note,
            "verification": ver, "latency_ms": int((time.time() - t0) * 1000), "record_hash": h}


def sample_questions(ds):
    qs = []
    if ds.df is not None:
        cats = {}
        for lst in ds.cat.values():
            for c, v in lst:
                cats.setdefault(c, []).append(v)
        for c in list(cats)[:2]:
            top = list(ds.df[c].astype(str).value_counts().index[:2])
            qs.append(f"How many records have {c.replace('_', ' ')} {top[0]}?")
            qs.append(f"What percentage of records have {c.replace('_', ' ')} {top[-1]}?")
        if cats:
            c = list(cats)[0]
            qs += [f"Count by {c.replace('_', ' ')}", f"What is the most common {c.replace('_', ' ')}?"]
        if ds.num:
            qs.append(f"What is the average {ds.num[0].replace('_', ' ')}?")
    qs.append("What is the capital of Kenya?")
    return qs
