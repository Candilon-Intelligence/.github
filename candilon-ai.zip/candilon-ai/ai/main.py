"""Candilon AI plane: API + UI. Talks to Ollama for generation; everything else is local code."""
import os, re, json, pathlib, threading, yaml, httpx
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel
import core

OLLAMA = os.getenv("OLLAMA_URL", "http://ollama:11434")
APPROVED = pathlib.Path("/approved")
CFG = {"router": yaml.safe_load(open(os.getenv("CANDILON_ROUTER_CONFIG", "/app/config/router.yaml"))),
       "models": yaml.safe_load(open(os.getenv("CANDILON_MODELS_CONFIG", "/app/config/models.yaml")))}
KEEP = CFG["models"].get("keep_alive", "5m")   # idle models unload after this: they "sleep"
STORE = core.Store()
PULL = {"name": "", "status": "idle", "completed": 0, "total": 0, "done": True, "error": None}
app = FastAPI(title="candilon-ai")


class AskReq(BaseModel):
    dataset_id: str
    question: str
    use_model: bool = True


class EvalReq(BaseModel):
    dataset_id: str
    questions: list[str]
    use_model: bool = True


class FromApproved(BaseModel):
    filename: str
    domain: str = "healthcare"


class PullReq(BaseModel):
    name: str


def installed():
    try:
        return [m["name"] for m in httpx.get(f"{OLLAMA}/api/tags", timeout=3).json().get("models", [])]
    except Exception:
        return None


def llm(messages, model):
    r = httpx.post(f"{OLLAMA}/api/chat", timeout=900, json={"model": model, "messages": messages, "stream": False, "keep_alive": KEEP,
                   "options": {"temperature": 0, "num_ctx": 2048, "num_predict": 200}})
    r.raise_for_status()
    return re.sub(r"<think>.*?</think>", "", r.json()["message"]["content"], flags=re.S).strip()


def get_ds(did):
    if did not in STORE.ds:
        raise HTTPException(404, "Dataset not found. Load data in the Data tab first.")
    return STORE.ds[did]


@app.get("/", include_in_schema=False)
def ui():
    return FileResponse("/app/ui/index.html")


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/config")
def config():
    return {"domains": list(CFG["router"]["domains"]) + ["general"], "experts": CFG["models"]["experts"],
            "suggested": CFG["models"].get("suggested", []), "require_verified": CFG["models"].get("require_verified_data", False)}


@app.get("/approved")
def approved():
    return core.list_approved(APPROVED) if APPROVED.exists() else []


@app.get("/datasets")
def datasets():
    return [d.meta for d in STORE.ds.values()]


@app.post("/datasets/upload")
async def upload(file: UploadFile = File(...), domain: str = Form("general")):
    if CFG["models"].get("require_verified_data"):
        raise HTTPException(403, "This installation only accepts data approved by the Candilon data plane.")
    try:
        return STORE.add(pathlib.Path(file.filename).name, await file.read(), domain, "upload")
    except ValueError as e:
        raise HTTPException(400, str(e))


@app.post("/datasets/from-approved")
def from_approved(req: FromApproved):
    p = APPROVED / pathlib.Path(req.filename).name
    if not p.is_file():
        raise HTTPException(404, "Approved file not found")
    info = next((a for a in core.list_approved(APPROVED) if a["filename"] == p.name), {})
    if CFG["models"].get("require_verified_data") and not info.get("verified"):
        raise HTTPException(403, "File is not verified against its approval manifest.")
    return STORE.add(p.name, p.read_bytes(), req.domain, "approved",
                     {"approver": info.get("approver"), "approved_at": info.get("approved_at"), "verified": bool(info.get("verified"))})


@app.delete("/datasets/{did}")
def delete(did: str):
    STORE.delete(did)
    return {"deleted": did}


@app.post("/ask")
def ask(req: AskReq):
    ds, inst = get_ds(req.dataset_id), installed()
    return core.ask(req.question, ds, CFG, llm if req.use_model else None, inst or [])


@app.get("/eval/sample")
def eval_sample(dataset_id: str):
    return core.sample_questions(get_ds(dataset_id))


@app.post("/eval")
def evaluate(req: EvalReq):
    ds, inst, rows = get_ds(req.dataset_id), installed(), []
    for q in [x.strip() for x in req.questions if x.strip()][:50]:
        r = core.ask(q, ds, CFG, llm if req.use_model else None, inst or [])
        rows.append({"question": q, "status": r["verification"]["status"], "task": r["router"]["task"], "language": r["router"]["language"],
                     "model": r["model"], "ms": r["latency_ms"], "answer": r["answer"][:160]})
    n = len(rows) or 1
    cnt = lambda s: sum(1 for x in rows if x["status"] == s)
    return {"rows": rows, "summary": {"questions": len(rows), "grounded": cnt("GROUNDED"), "partial": cnt("PARTIAL"), "unsupported": cnt("UNSUPPORTED"),
            "abstained": cnt("ABSTAINED"), "grounded_rate": round(cnt("GROUNDED") / n, 3), "avg_ms": int(sum(x["ms"] for x in rows) / n)}}


def loaded():
    try:
        return [m["name"] for m in httpx.get(f"{OLLAMA}/api/ps", timeout=3).json().get("models", [])]
    except Exception:
        return []


@app.get("/models/status")
def models_status():
    inst = installed()
    return {"ollama": inst is not None, "installed": inst or [], "loaded": loaded(), "keep_alive": KEEP, "pull": PULL}


def _pull(name):
    PULL.update(name=name, status="starting", completed=0, total=0, done=False, error=None)
    try:
        with httpx.stream("POST", f"{OLLAMA}/api/pull", json={"model": name, "name": name, "stream": True}, timeout=None) as r:
            for line in r.iter_lines():
                if not line:
                    continue
                d = json.loads(line)
                if d.get("error"):
                    raise RuntimeError(d["error"])
                PULL.update(status=d.get("status", ""), completed=d.get("completed", PULL["completed"]), total=d.get("total", PULL["total"]))
        PULL.update(done=True, status="success")
        core.prov_add("model_installed", "-", {"model": name})
    except Exception as e:
        PULL.update(done=True, error=str(e)[:200], status="failed")


@app.post("/models/pull")
def pull(req: PullReq):
    if not PULL["done"]:
        raise HTTPException(409, f"Already downloading {PULL['name']}")
    threading.Thread(target=_pull, args=(req.name.strip(),), daemon=True).start()
    return {"started": req.name}


@app.get("/provenance")
def provenance(limit: int = 100):
    return core.prov_list(limit)


@app.get("/provenance/verify")
def provenance_verify():
    return core.prov_verify()
