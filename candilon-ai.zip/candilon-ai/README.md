# Candilon AI plane (models + RAG + UI)

Separate from the data-plane stack. Put this folder next to `candilon/` (e.g. `~/candilon` and `~/candilon-ai`).

    cd ~/candilon-ai
    ./start.sh              # builds the UI/API and starts the model runtime; opens http://localhost:8081
    ./pull_model.sh gemma2:2b   # or use the Models tab. Models are stored in ./models and work offline afterwards.
    ./stop.sh

## Use
1. Data tab: pick a file approved by the data plane (marked verified when it matches its approval manifest) or upload a cleaned CSV / .txt / .md.
2. Ask tab: ask a question. The router picks language, domain, task and expert slot. Counting/averaging questions are computed
   from the table (no free-form SQL); other questions retrieve passages (BM25). The model only phrases the answer from the evidence.
3. Every answer is verified (numbers in evidence, citations real, computed value stated). Unsupported model answers are replaced
   by the computed answer. No evidence means "INSUFFICIENT EVIDENCE".
4. Evaluate tab: run many questions and read the grounded rate. Provenance tab: hash-chained record of datasets, models and answers.

## Settings (config/)
- `models.yaml`: which model each expert slot uses (any Ollama name), fallbacks, and `require_verified_data: true` for hospitals.
- `router.yaml`: domain keywords and Swahili cue words.

## Limits (be honest in demos)
- Experts are configuration slots pointing at general open models; none are fine-tuned yet.
- Retrieval is keyword-based (BM25), tuned for English column values. Swahili questions work when they contain the data's values (e.g. "Wagonjwa wangapi wana asthma?").
  Kalenjin and other languages are not handled yet.
- No login. Keep it on localhost or a trusted network.
- 8 GB laptop: use a 2-4B model; the first model download needs internet.

## Google Colab
No Docker on Colab. Use `Candilon_AI_Colab.ipynb` (upload this zip to My Drive, choose a T4 GPU runtime, run cells 1 to 6).
`config/models.colab.yaml` gives each expert slot its own small model; idle models unload after `keep_alive` (2 minutes), so the
expert cards show ACTIVE, LOADED (idle) or SLEEPING from the runtime's real state. Use synthetic or approved de-identified data only.
