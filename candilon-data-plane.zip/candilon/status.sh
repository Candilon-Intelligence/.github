#!/usr/bin/env bash
cd "$(dirname "$0")"
echo "Candilon Status"
docker compose ps --format 'table {{.Service}}\t{{.State}}\t{{.Health}}'
