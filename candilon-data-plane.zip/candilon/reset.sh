#!/usr/bin/env bash
# Wipe all processed data, reports and the database so the next demo starts clean. Files in data/incoming are kept.
cd "$(dirname "$0")"
read -r -p "This deletes all Candilon results and the database. Continue? [y/N] " a
[ "$a" = "y" ] || exit 0
docker compose --profile demo down -v
for d in data/processing data/approved data/quarantine data/exports reports; do find "$d" -type f ! -name .gitkeep -delete; done
find data/processing -mindepth 1 -type d -empty -delete
echo "Clean. Run ./start.sh demo"
