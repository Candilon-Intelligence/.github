# Licensing: what happens if an institution stops paying

**Design:** each institution gets a signed licence file (`config/license.json`). The appliance verifies it offline
(Ed25519 public key). No internet, no phoning home, no patient data ever leaves the site.

| State | When | Behaviour |
|---|---|---|
| trial | No licence file, first 30 days | Everything works, banner shows days left |
| active | Before expiry | Everything works |
| grace | 14 days after expiry (configurable) | Works, banner asks to renew |
| expired / invalid | After grace | **New processing is paused** (HTTP 402). Dashboard, reports, provenance, audit and already-approved files stay available |

Rolling the system clock back does not extend a licence (last-seen date is stored).

**Why it never deletes or locks existing data:** hospitals and regulators will not accept a system that can hold patient
data hostage or be remotely switched off. "Pause new work, keep access to your own results" is enforceable and defensible.

## Issuing licences (you, the founder)
    ./start.sh                       # once, so the api image exists
    ./license.sh keygen              # once. Back up license/private.pem. NEVER ship it.
    ./license.sh issue --customer "Hospital A" --days 365 --plan pilot
    # send license/hospital-a.license.json; customer saves it as config/license.json, then: docker compose restart api
    # renewal = issue a new file with a later date

## Honest limits
Software that runs on a customer's machine can always be tampered with by someone who has the source and admin rights.
The licence stops honest customers from drifting past their contract; it is not DRM. Real protection is:
1. Ship built images, not source; bake your public key into the image at build time (the config-mounted key is the demo setup).
2. Contract terms, plus value that needs you: updates, support, new language/domain adapters, hosted model access, policy packs.
3. Keep the private key off every customer machine.
Before shipping a package: remove `license/`, `tools/`, `secrets/*.txt`, `data/*` and `reports/*` contents.
