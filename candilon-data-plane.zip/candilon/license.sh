#!/usr/bin/env bash
# Founder-only. Usage:
#   ./license.sh keygen
#   ./license.sh issue --customer "Aga Khan Hospital" --days 365 --plan pilot
#   ./license.sh show license/aga-khan-hospital.license.json
cd "$(dirname "$0")"
mkdir -p license
docker compose run --rm --no-deps --user "$(id -u):$(id -g)" \
  -v "$PWD/tools:/tools:ro" -v "$PWD/license:/license" -v "$PWD/config:/candilon/config" \
  --entrypoint python api /tools/license_tool.py "$@"
