#!/usr/bin/env bash
# Usage: bash start_colab.sh [demo]   Starts database, ARX, privacy, api and the dashboard on port 8088.
set -e
ROOT=$(cd "$(dirname "$0")/.." && pwd)
LOG=/tmp/candilon-logs; mkdir -p $LOG
bash "$(dirname "$0")/stop_colab.sh" >/dev/null 2>&1 || true

# Services expect /candilon and /run/secrets (as in Docker)
ln -sfn "$ROOT" /candilon
mkdir -p "$ROOT/secrets" /run/secrets
[ -s "$ROOT/secrets/db_password.txt" ] || head -c 24 /dev/urandom | od -An -tx1 | tr -d ' \n' > "$ROOT/secrets/db_password.txt"
[ -s "$ROOT/secrets/pseudo_salt.txt" ] || head -c 32 /dev/urandom | od -An -tx1 | tr -d ' \n' > "$ROOT/secrets/pseudo_salt.txt"
cp "$ROOT/secrets/db_password.txt" "$ROOT/secrets/pseudo_salt.txt" /run/secrets/ 2>/dev/null || true
cp "$ROOT/secrets/db_password.txt" /run/secrets/db_password; cp "$ROOT/secrets/pseudo_salt.txt" /run/secrets/pseudo_salt
PW=$(cat /run/secrets/db_password)

echo "Database..."
service postgresql start >/dev/null
sleep 3
su postgres -c "psql" >/dev/null 2>&1 <<SQL || true
CREATE ROLE candilon LOGIN PASSWORD '$PW';
SQL
su postgres -c "psql" >/dev/null <<SQL
ALTER ROLE candilon PASSWORD '$PW';
SQL
su postgres -c "createdb -O candilon candilon" >/dev/null 2>&1 || true

[ "${1:-}" = "demo" ] && python3 "$ROOT/privacy/seed.py"

echo "ARX..."
(cd "$ROOT/arx" && nohup "$(ls -d /usr/lib/jvm/java-21-openjdk-*/bin/java | head -1)" -Xmx2g -cp "target/arx-service.jar:lib/*" Main > $LOG/arx.log 2>&1 &)
echo "Privacy engine..."
(cd "$ROOT/privacy" && DATA_PATH=/candilon/data REPORT_PATH=/candilon/reports CONFIG_PATH=/candilon/config \
  nohup uvicorn engine:app --host 127.0.0.1 --port 8001 > $LOG/privacy.log 2>&1 &)
echo "API..."
(cd "$ROOT/api" && DATABASE_HOST=127.0.0.1 PRIVACY_URL=http://127.0.0.1:8001 ARX_URL=http://127.0.0.1:8080 \
  nohup uvicorn main:app --host 127.0.0.1 --port 8000 > $LOG/api.log 2>&1 &)

echo "Dashboard..."
cat > /tmp/candilon-nginx.conf <<NGX
pid /tmp/candilon-nginx.pid;
error_log $LOG/nginx.log;
events {}
http {
  include /etc/nginx/mime.types;
  access_log off;
  server {
    listen 8088;
    client_max_body_size 2g;
    root $ROOT/dashboard;
    location /api/ { proxy_pass http://127.0.0.1:8000/; proxy_read_timeout 3600s; }
    location / { try_files \$uri /index.html; }
  }
}
NGX
nginx -c /tmp/candilon-nginx.conf

for i in $(seq 1 60); do
  curl -sf http://127.0.0.1:8000/health >/dev/null && curl -sf http://127.0.0.1:8001/health >/dev/null \
    && curl -sf http://127.0.0.1:8080/health >/dev/null && { echo "Candilon is up on port 8088."; exit 0; }
  sleep 2
done
echo "Something did not start. Logs in $LOG:"; tail -n 15 $LOG/*.log; exit 1
