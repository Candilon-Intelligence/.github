#!/usr/bin/env bash
pkill -f "arx-service.jar" 2>/dev/null; pkill -f "uvicorn engine:app" 2>/dev/null; pkill -f "uvicorn main:app" 2>/dev/null
[ -f /tmp/candilon-nginx.pid ] && kill "$(cat /tmp/candilon-nginx.pid)" 2>/dev/null
echo stopped
