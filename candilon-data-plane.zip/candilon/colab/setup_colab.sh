#!/usr/bin/env bash
# Run ONCE per Colab session. Installs Java, Maven, PostgreSQL, nginx, Python deps and builds the ARX service.
# Colab cannot run Docker, so Candilon runs here as plain processes (same code, same ports logic).
set -e
ROOT=$(cd "$(dirname "$0")/.." && pwd)
export DEBIAN_FRONTEND=noninteractive
echo "[1/3] System packages (Java 21, PostgreSQL, nginx)..."
apt-get -qq update
apt-get -qq install -y openjdk-21-jdk-headless postgresql nginx >/dev/null
service nginx stop >/dev/null 2>&1 || true
echo "[2/3] Python packages..."
pip -q install fastapi "uvicorn[standard]" httpx "psycopg[binary]" pyyaml python-multipart "pandas>=2.1" numpy openpyxl pydantic
echo "[3/3] Getting ARX and compiling the ARX service..."
bash "$ROOT/arx/get_arx.sh"
cd "$ROOT/arx"
JAVAC=$(ls -d /usr/lib/jvm/java-21-openjdk-*/bin/javac | head -1); JAR=$(dirname $JAVAC)/jar
rm -rf out && mkdir out && $JAVAC -cp "lib/*" -d out src/Main.java && mkdir -p target && $JAR cf target/arx-service.jar -C out .
echo "Setup complete."
