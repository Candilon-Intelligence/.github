"""Candilon privacy engine: ingestion -> cleaning -> PII -> de-identification -> quality -> report."""
import os, re, json, math, hmac, hashlib, pathlib, html
import numpy as np, pandas as pd, yaml
from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel

DATA = pathlib.Path(os.getenv("DATA_PATH", "/candilon/data"))
REPORTS = pathlib.Path(os.getenv("REPORT_PATH", "/candilon/reports"))
CFG = yaml.safe_load(open(os.getenv("CONFIG_PATH", "/candilon/config") + "/privacy.yaml"))
SALT = open("/run/secrets/pseudo_salt").read().strip().encode()
app = FastAPI(title="candilon-privacy")


@app.exception_handler(Exception)
async def boom(request, exc):
    """Return the real error text so the dashboard shows what went wrong instead of 'Internal Server Error'."""
    return JSONResponse({"detail": f"{type(exc).__name__}: {exc}"}, status_code=500)


def fin(v):
    try:
        v = float(v)
    except (TypeError, ValueError):
        return None
    return v if math.isfinite(v) else None


def safe(o):
    """Make results JSON-safe: NaN/inf become null, numpy numbers become Python numbers."""
    if isinstance(o, dict):
        return {str(k): safe(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [safe(v) for v in o]
    if isinstance(o, float) or hasattr(o, "item"):
        v = o.item() if hasattr(o, "item") else o
        return fin(v) if isinstance(v, float) else v
    return o


class Req(BaseModel):
    dataset_id: str


class PReq(Req):
    quasi_identifiers: list[str] = []
    sensitive: str | None = None


class RReq(Req):
    stages: dict = {}
    provenance: list = []


# Order matters: more specific patterns first so text is consumed once.
PATTERNS = [
    ("mrn", r"(?i)\bMRN[:#\s-]*\d{5,10}\b"),
    ("national_id", r"(?<!\d)\d{3}-\d{2}-\d{4}(?!\d)|\b[A-Z]{2}\d{6,9}\b"),
    ("email", r"[\w.+-]+@[\w-]+\.[\w.-]+"),
    ("address", r"\b\d{1,5}\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\s+(?:Street|St|Road|Rd|Avenue|Ave|Lane|Ln|Drive|Dr)\b"),
    ("name", r"\b(?:Dr|Mr|Mrs|Ms|Miss|Prof)\.?\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)?|\b(?:Patient|Mother|Father|Wife|Husband|Son|Daughter|Contact)\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)?"),
    ("date", r"\b\d{4}-\d{2}-\d{2}\b|\b\d{1,2}/\d{1,2}/\d{2,4}\b"),
    ("phone", r"(?<!\d)(?:\+\d{1,3}[\s.-]?)?\(?\d{3,4}\)?[\s.-]?\d{3}[\s.-]?\d{3,4}(?!\d)"),
]
NULLS = {"", "na", "n/a", "null", "none", "nan", "-", "--", "?"}


def ddir(ds):
    p = DATA / "processing" / ds
    if not p.exists():
        raise HTTPException(404, f"unknown dataset {ds}")
    return p


def colcat(col):
    for cat, hints in CFG["column_hints"].items():
        if any(h in col for h in hints):
            return cat
    return None


def read_any(path):
    ext = path.suffix.lower()
    if ext in (".xlsx", ".xls"):
        sheets = pd.read_excel(path, sheet_name=None)
        frames = [t.assign(source_sheet=n) for n, t in sheets.items() if not t.empty]
        df = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()
        if len(frames) <= 1 and "source_sheet" in df.columns:
            df = df.drop(columns="source_sheet")
    elif ext == ".json":
        raw = json.load(open(path))
        if isinstance(raw, dict):
            lists = [v for v in raw.values() if isinstance(v, list) and v and isinstance(v[0], dict)]
            raw = lists[0] if lists else [raw]
        df = pd.json_normalize(raw, sep="_")
    else:
        head = open(path, "r", errors="ignore").read(4096)
        sep = max([",", ";", "\t", "|"], key=head.count)
        df = pd.read_csv(path, dtype=str, keep_default_na=False, sep=sep)
    return df.astype("string")


def count_patterns(s, skip=()):
    found = {}
    s = s.dropna()
    for cat, pat in PATTERNS:
        if cat in skip:
            continue
        n = int(s.str.count(pat).sum())
        if n:
            found[cat] = n
            s = s.str.replace(pat, "\x00", regex=True)
    return found


def redact(s, skip=()):
    for cat, pat in PATTERNS:
        if cat not in skip:
            s = s.str.replace(pat, f"[{cat.upper()}]", regex=True)
    return s


def pseud(v):
    if pd.isna(v):
        return v
    d = hmac.new(SALT, str(v).encode(), hashlib.sha256).hexdigest()[:16]
    return "psn" + d.translate(str.maketrans("0123456789", "ghijklmnop"))  # letters only: no digit runs


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/clean")
def clean(r: Req):
    d = ddir(r.dataset_id)
    meta = json.load(open(d / "meta.json"))
    df = read_any(DATA / "incoming" / meta["filename"])
    rows_in = len(df)
    renamed = {}
    for c in df.columns:
        n = re.sub(r"[^0-9a-z]+", "_", str(c).strip().lower()).strip("_") or "col"
        renamed[c] = n
    df.columns = list(renamed.values())
    date_bad = {}
    for c in df.columns:
        df[c] = df[c].str.strip().str.replace(r"\s+", " ", regex=True)
        df[c] = df[c].mask(df[c].str.lower().isin(NULLS))
        cat = colcat(c)
        if "date" in c or cat == "dob":
            p = pd.to_datetime(df[c], errors="coerce", format="mixed")
            date_bad[c] = int((df[c].notna() & p.isna()).sum())
            df[c] = p.dt.strftime("%Y-%m-%d").astype("string")
        elif c in ("gender", "sex"):
            m = {"m": "male", "male": "male", "man": "male", "f": "female", "female": "female", "woman": "female"}
            low = df[c].str.lower()
            df[c] = low.map(m).fillna(low).astype("string")
        elif cat is None:
            n = pd.to_numeric(df[c], errors="coerce")
            if df[c].notna().sum() and n.notna().sum() / df[c].notna().sum() >= 0.98:
                df[c] = n
    miss_row = df.isna().mean(axis=1)
    bad = miss_row > CFG["quarantine_row_missing_fraction"]
    if bad.any():
        (DATA / "quarantine").mkdir(parents=True, exist_ok=True)
        df[bad].to_csv(DATA / "quarantine" / f"{r.dataset_id}_rows.csv", index=False)
    df = df[~bad]
    dups = int(df.duplicated().sum())
    df = df.drop_duplicates().reset_index(drop=True)
    df.to_csv(d / "cleaned.csv", index=False)
    return {
        "rows_in": rows_in, "rows_out": len(df), "quarantined_rows": int(bad.sum()),
        "duplicates_removed": dups, "columns": len(df.columns),
        "columns_renamed": sum(1 for a, b in renamed.items() if a != b),
        "unparsable_dates": date_bad,
        "missing_fraction": {c: round(float(df[c].isna().mean()), 4) for c in df.columns},
        "schema": {c: str(df[c].dtype) for c in df.columns},
    }


@app.post("/scan-pii")
def scan(r: Req):
    d = ddir(r.dataset_id)
    df = pd.read_csv(d / "cleaned.csv", dtype=str)
    structured, embedded, by_col = {}, {}, {}
    for c in df.columns:
        cat = colcat(c)
        if cat and cat != "free_text":
            n = int(df[c].notna().sum())
            structured[cat] = structured.get(cat, 0) + n
            by_col[c] = {cat: n}
        else:
            f = count_patterns(df[c])
            if f:
                by_col[c] = f
            for k, v in f.items():
                embedded[k] = embedded.get(k, 0) + v
    out = {"structured": structured, "embedded": embedded, "by_column": by_col,
           "total_findings": sum(structured.values()) + sum(embedded.values()),
           "categories": sorted(set(structured) | set(embedded)),
           "records_scanned": len(df)}
    json.dump(out, open(d / "pii_findings.json", "w"), indent=1)
    return out


def _widen(v):
    if pd.isna(v) or not str(v)[:1].isdigit() or "+" in str(v):
        return v
    s20 = int(str(v).split("-")[0]) // 20 * 20
    return f"{s20}-{s20 + 19}"


def enforce_group_size(out, qi, k, max_frac):
    """Make every combination of quasi-identifiers appear at least k times: coarsen, then suppress rare records."""
    steps, sup = [], []
    if not qi or len(out) == 0:
        return out, steps, sup
    size = lambda: int(out.groupby(qi, dropna=False).size().min())
    if size() >= k:
        return out, steps, sup
    zc = [c for c in qi if c.endswith("_3digit")]
    levels = [("coarsened ZIP to 2 digits and age bands to 20 years", 2, True), ("coarsened ZIP to 1 digit", 1, False),
              ("removed ZIP detail entirely", 0, False)]
    for text, digits, widen in levels:
        if not zc and not (widen and "age_band" in qi):
            continue
        for c in zc:
            out[c] = out[c].str[:digits] if digits else "*"
        if widen and "age_band" in qi:
            out["age_band"] = out["age_band"].map(_widen)
        steps.append(text)
        if size() >= k:
            return out, steps, sup
    n = out.groupby(qi, dropna=False)[qi[0]].transform("size")
    small = n < k
    if small.mean() <= max_frac:
        sup = list(out.index[small])
        out = out[~small]
        steps.append(f"suppressed {len(sup)} records in groups smaller than {k}")
    else:
        steps.append(f"could not reach group size {k} without removing more than {int(max_frac * 100)}% of records: dataset is too small or too distinctive")
    return out, steps, sup


@app.post("/deidentify")
def deidentify(r: Req):
    d = ddir(r.dataset_id)
    df = pd.read_csv(d / "cleaned.csv", dtype=str)
    acts, out = CFG["actions"], pd.DataFrame(index=df.index)
    applied = {}
    for c in df.columns:
        cat = colcat(c)
        a = acts.get(cat) if cat else None
        s = df[c]
        if a == "drop":
            applied[c] = "drop"
        elif a == "pseudonymize":
            out[c] = s.map(pseud); applied[c] = "pseudonymize"
        elif a == "age_band":
            age = pd.Timestamp.now().year - pd.to_datetime(s, errors="coerce").dt.year
            band = (age // 10 * 10).astype("Int64")
            lab = band.astype("string") + "-" + (band + 9).astype("string")
            out["age_band"] = lab.mask((band >= 90).fillna(False), "90+"); applied[c] = "age_band"
        elif a == "zip3":
            out[f"{c}_3digit"] = s.str[:3]; applied[c] = "zip3"
        elif a == "redact":
            out[c] = redact(s); applied[c] = "redact"
        elif CFG.get("generalize_date_columns_to_month") and "date" in c:
            out[c] = s.str[:7]; applied[c] = "month"
        else:
            out[c] = redact(s, skip=("date",))
            applied[c] = "keep"
    k = int(CFG.get("min_group_size", 5))
    qi_l = [c for c in out.columns if any(h in c for h in CFG["quasi_identifier_hints"])]
    out, steps, sup_idx = enforce_group_size(out, qi_l, k, float(CFG.get("max_suppressed_fraction", 0.2)))
    json.dump([int(i) for i in sup_idx], open(d / "deid_suppressed.json", "w"))
    out.to_csv(d / "deidentified.csv", index=False)
    json.dump(applied, open(d / "deid_actions.json", "w"))
    residual = {}
    for c in out.columns:
        for k, v in count_patterns(out[c].astype("string")).items():
            residual[k] = residual.get(k, 0) + v
    qi = [c for c in out.columns if any(h in c for h in CFG["quasi_identifier_hints"])]
    sens = next((c for c in out.columns if any(h in c for h in CFG["sensitive_hints"])), None)
    qi_before = [c for c, a in applied.items() if a in ("age_band", "zip3")] + [c for c in qi if c in df.columns and applied.get(c) == "keep"]
    return {"actions": applied, "quasi_identifiers_before": qi_before, "k_target": k, "generalization_steps": steps, "suppressed_rows": len(sup_idx), "columns_dropped": [c for c, a in applied.items() if a == "drop"],
            "columns_out": list(out.columns), "quasi_identifiers": qi, "sensitive": sens,
            "rows": len(out), "residual_pii_findings": sum(residual.values()), "residual_by_category": residual}


@app.post("/privacy-extra")
def privacy_extra(r: PReq):
    """l-diversity and t-closeness (k-anonymity, uniqueness and risk come from ARX)."""
    d = ddir(r.dataset_id)
    df = pd.read_csv(d / "deidentified.csv", dtype=str)
    if not r.quasi_identifiers or not r.sensitive or r.sensitive not in df.columns:
        return {"l_diversity": None, "t_closeness": None}
    qi, s = r.quasi_identifiers, r.sensitive
    l = int(df.groupby(qi, dropna=False)[s].nunique().min())
    ct = df.groupby(qi + [s], dropna=False).size().unstack(fill_value=0)
    q = ct.div(ct.sum(axis=1), axis=0)
    p = ct.sum() / ct.values.sum()
    t = float((0.5 * (q - p).abs().sum(axis=1)).max())
    return safe({"l_diversity": l, "t_closeness": round(t, 4), "sensitive_attribute": s})


@app.post("/quality")
def quality(r: Req):
    d = ddir(r.dataset_id)
    a = pd.read_csv(d / "cleaned.csv", dtype=str)
    b = pd.read_csv(d / "deidentified.csv", dtype=str)
    acts = json.load(open(d / "deid_actions.json"))
    sup_f = d / "deid_suppressed.json"
    sup = json.load(open(sup_f)) if sup_f.exists() else []
    if sup:
        a = a.drop(index=sup, errors="ignore").reset_index(drop=True)
    analytic = [c for c in a.columns if acts.get(c) not in ("drop", "pseudonymize")]
    tot = mod = 0
    for c in analytic:
        nn = int(a[c].notna().sum()); tot += nn
        mod += int((a[c].fillna("") != b[c].fillna("")).sum()) if c in b.columns else nn
    info_loss = mod / tot if tot else 0.0
    common = [c for c in a.columns if c in b.columns]
    miss = {c: {"before": round(float(a[c].isna().mean()), 4), "after": round(float(b[c].isna().mean()), 4)} for c in common}
    miss_delta = float(np.mean([max(0, v["after"] - v["before"]) for v in miss.values()])) if miss else 0.0
    dist = {}
    for c in common:
        x, y = pd.to_numeric(a[c], errors="coerce"), pd.to_numeric(b[c], errors="coerce")
        if x.notna().mean() > 0.9 and fin(x.mean()) is not None:
            if y.notna().sum() == 0:      # numeric values were lost or replaced by text
                dist[c] = {"mean_shift_pct": 100.0, "std_shift_pct": 100.0, "note": "numeric values no longer numeric after de-identification"}
                continue
            mx, my, sx, sy = fin(x.mean()), fin(y.mean()), fin(x.std()), fin(y.std())
            dist[c] = {"mean_shift_pct": round(abs(my - mx) / (abs(mx) or 1) * 100, 3),
                       "std_shift_pct": None if (sx is None or sy is None) else round(abs(sy - sx) / (abs(sx) or 1) * 100, 3)}
    shift = float(np.mean([v["mean_shift_pct"] / 100 for v in dist.values()])) if dist else 0.0
    card = {c: {"before": int(a[c].nunique()), "after": int(b[c].nunique())} for c in common if acts.get(c) in ("zip3", "month", "redact")}
    utility = max(0.0, min(1.0, 1 - 0.5 * info_loss - miss_delta - shift))
    total_rows = len(a) + len(sup)
    return safe({"information_loss": round(info_loss, 4), "utility_score": round(utility, 4),
            "missingness_increase": round(miss_delta, 4), "numeric_distribution_shift": dist,
            "cardinality_change": card, "missingness": miss,
            "columns_retained": len(common), "columns_removed": len(a.columns) - len(common),
                 "records_suppressed": len(sup), "suppressed_fraction": round(len(sup) / total_rows, 4) if total_rows else 0.0,
                 "utility_breakdown": {"information_loss_penalty": round(0.5 * info_loss, 4), "missingness_penalty": round(miss_delta, 4),
                                       "distribution_shift_penalty": round(shift, 4)}})


def mask(v):
    if v is None or pd.isna(v):
        return ""
    t = str(v)
    return t if len(t) <= 2 else t[:2] + re.sub(r"[A-Za-z0-9]", "\u2022", t[2:])


def sample(d, n, raw=False):
    a = pd.read_csv(d / "cleaned.csv", dtype=str, nrows=n)
    b = pd.read_csv(d / "deidentified.csv", dtype=str, nrows=n).fillna("")
    a = a.fillna("") if raw else a.apply(lambda c: c.map(mask))
    return a, b


@app.get("/preview")
def preview(dataset_id: str, n: int = 6, raw: bool = False):
    """Before/after rows. Real 'before' values are only shown in demo mode; otherwise they are masked."""
    d = ddir(dataset_id)
    allow = raw and os.getenv("CANDILON_MODE", "demo") == "demo"
    a, b = sample(d, min(n, 20), allow)
    return {"raw_shown": allow, "before": {"columns": list(a.columns), "rows": a.values.tolist()},
            "after": {"columns": list(b.columns), "rows": b.values.tolist()}}


E = html.escape


def tbl(head, rows):
    return ("<table><tr>" + "".join(f"<th>{E(str(h))}</th>" for h in head) + "</tr>" +
            "".join("<tr>" + "".join(f"<td>{E(str(c))}</td>" for c in r) + "</tr>" for r in rows) + "</table>")


def pct(x):
    return f"{x * 100:.1f}%" if isinstance(x, (int, float)) else "n/a"


@app.post("/report")
def report(r: RReq):
    folder = {"clean": "quality", "pii": "pii", "deid": "pii", "privacy": "privacy", "quality": "quality", "approve": "verification"}
    for st, res in r.stages.items():
        if st in folder:
            (REPORTS / folder[st]).mkdir(parents=True, exist_ok=True)
            json.dump(res, open(REPORTS / folder[st] / f"{r.dataset_id}.{st}.json", "w"), indent=1)
    (REPORTS / "provenance").mkdir(parents=True, exist_ok=True)
    json.dump(r.provenance, open(REPORTS / "provenance" / f"{r.dataset_id}.json", "w"), indent=1)
    S = r.stages
    pii, de, pv, qu, ap, cl = (S.get(k) or {} for k in ("pii", "deid", "privacy", "quality", "approve", "clean"))
    bf = pv.get("before") or {}
    out = []
    if pv and de:
        rows = [("PII findings", pii.get("total_findings", "n/a"), de.get("residual_pii_findings", "n/a")),
                ("Smallest group size (k-anonymity)", bf.get("k_anonymity", "n/a"), pv.get("k_anonymity")),
                ("Highest re-identification risk", pct(bf.get("highest_reidentification_risk")), pct(pv.get("highest_reidentification_risk"))),
                ("Average re-identification risk", pct(bf.get("average_reidentification_risk")), pct(pv.get("average_reidentification_risk"))),
                ("Records unique on quasi-identifiers", pct(bf.get("fraction_unique_records")), pct(pv.get("fraction_unique_records")))]
        out.append("<h2>Before and after</h2>" + tbl(["Measure", "Before", "After"], rows))
        qb = ", ".join(de.get("quasi_identifiers_before", [])) or "n/a"
        qa = ", ".join(de.get("quasi_identifiers", [])) or "n/a"
        out.append(f"<p class=m>Quasi-identifiers measured: before = {E(qb)}; after = {E(qa)}. Engine: {E(str(pv.get('engine', 'ARX')))}.</p>")
        keys = [("Records", "records"), ("Equivalence classes", "equivalence_classes"), ("Average class size", "avg_class_size"),
                ("Largest class", "max_class_size"), ("l-diversity", "l_diversity"), ("t-closeness", "t_closeness")]
        out.append("<h2>ARX details</h2>" + tbl(["Metric", "Before", "After"], [(n, bf.get(k, "-"), pv.get(k, "-")) for n, k in keys]))
    if ap:
        out.append(f"<h2>Approval gate: {E(str(ap.get('decision', '')).upper())}</h2><p class=m>Approver: {E(str(ap.get('approver') or 'none'))}</p>" +
                   tbl(["Check", "Value", "Rule", "Result"], [(c["name"], c["value"], c["rule"], "PASS" if c["passed"] else "FAIL") for c in ap.get("checks", [])]))
    if pii:
        cats = sorted(set(pii.get("structured", {})) | set(pii.get("embedded", {})))
        out.append("<h2>PII discovered</h2>" + tbl(["Category", "In structured fields", "Embedded in text"],
                   [(c, pii["structured"].get(c, 0), pii["embedded"].get(c, 0)) for c in cats]))
    if de:
        out.append("<h2>De-identification actions</h2>" + tbl(["Column", "Action"], list(de.get("actions", {}).items())))
    if qu:
        out.append("<h2>Data quality</h2>" + tbl(["Measure", "Value"], [
            ("Information loss", pct(qu.get("information_loss"))), ("Utility score", pct(qu.get("utility_score"))),
            ("Missingness increase", pct(qu.get("missingness_increase"))), ("Columns retained", qu.get("columns_retained")),
            ("Columns removed", qu.get("columns_removed"))]))
    if cl:
        out.append("<h2>Cleaning</h2>" + tbl(["Measure", "Value"], [(k.replace("_", " "), cl.get(k)) for k in
                   ("rows_in", "rows_out", "duplicates_removed", "quarantined_rows", "columns_renamed")]))
    d = DATA / "processing" / r.dataset_id
    if (d / "deidentified.csv").exists():
        a, b = sample(d, 5)
        out.append("<h2>Sample rows</h2><p class=m>Before values are masked in this report. No raw identifiers are included.</p><h3>Before (masked)</h3>"
                   + tbl(a.columns, a.values.tolist()) + "<h3>After</h3>" + tbl(b.columns, b.values.tolist()))
    prov = tbl(["Time", "Stage", "Actor", "Record hash"], [(p.get("ts"), p.get("stage"), p.get("actor"), str(p.get("record_hash"))[:16]) for p in r.provenance])
    page = f"""<!doctype html><meta charset=utf-8><title>Candilon evidence report {E(r.dataset_id)}</title>
<style>body{{font:15px/1.5 system-ui,sans-serif;max-width:980px;margin:2rem auto;padding:0 1rem;color:#14212B}}
h1{{margin-bottom:0}}h2{{margin-top:2rem;border-bottom:2px solid #0b6e6e;padding-bottom:4px}}table{{border-collapse:collapse;width:100%;font-size:13px;display:block;overflow-x:auto}}
th,td{{padding:5px 10px;text-align:left;border-bottom:1px solid #d3dce2;white-space:nowrap}}th{{background:#eef2f4}}.m{{color:#5d6d7a;font-size:13px}}</style>
<h1>Candilon evidence report</h1><p class=m>Dataset {E(r.dataset_id)}. Generated from measured pipeline results.</p>
{''.join(out)}<h2>Provenance chain</h2>{prov}"""
    (REPORTS / f"{r.dataset_id}.html").write_text(page)
    return {"report": f"{r.dataset_id}.html"}
