import random, csv, pathlib
random.seed(7)
out = pathlib.Path("/candilon/data/incoming/demo_patients.csv")
first = ["Amina", "John", "Grace", "Samuel", "Linda", "Peter", "Zara", "David", "Mary", "Ibrahim"]
last = ["Okafor", "Smith", "Mensah", "Jones", "Kamau", "Brown", "Diallo", "Taylor"]
dx = ["Pneumonia", "Malaria", "Hypertension", "Diabetes", "Asthma", "Fracture", "Typhoid"]
streets = ["Market Street", "Church Road", "Palm Avenue", "Hill Lane"]
ZIPS = [f"{z}{random.randint(10,99)}" for z in (100,112,303,331,606,770,850,900,941,981,372,452)]
rows = []
for i in range(5000):
    f, l = random.choice(first), random.choice(last)
    y, m, d = random.randint(1940, 2015), random.randint(1, 12), random.randint(1, 28)
    dob = random.choice([f"{y}-{m:02d}-{d:02d}", f"{d:02d}/{m:02d}/{y}"])
    doc = f"Dr. {random.choice(last)}"
    note = random.choice([f"Patient {f} {l} seen by {doc}. Call back on +234 803 555 {random.randint(1000,9999)}.",
                          f"Discharged home. Contact {f.lower()}.{l.lower()}@mail.com. MRN {random.randint(100000,999999)}.",
                          f"Lives at {random.randint(1,99)} {random.choice(streets)}. Stable.", "Routine follow-up."])
    rows.append([f"P{i:05d}", f" {f.upper()} {l} " if i % 9 == 0 else f"{f} {l}", dob,
                 random.choice(["M", "F", "male", "Female"]), f"+234 80{random.randint(1,9)} {random.randint(100,999)} {random.randint(1000,9999)}",
                 f"{f.lower()}{i}@mail.com", f"{random.randint(100,999)}-{random.randint(10,99)}-{random.randint(1000,9999)}",
                 f"{random.randint(1,99)} {random.choice(streets)}", random.choice(ZIPS),
                 f"2026-{random.randint(1,9):02d}-{random.randint(1,28):02d}", random.choice(dx), random.choice(["3", "5", "N/A", "7", "10", "2"]), note])
rows += [rows[10], rows[20], ["", "", "", "", "", "", "", "", "", "", "", "", ""]]  # duplicates + junk row
with open(out, "w", newline="") as fh:
    w = csv.writer(fh)
    w.writerow(["Patient ID", "Full Name", "DOB", "Gender", "Phone", "Email", "National ID", "Address", "ZIP", "Admission Date", "Diagnosis", "Length of Stay", "Clinical Notes"])
    w.writerows(rows)
print("wrote", out)
