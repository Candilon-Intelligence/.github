#!/usr/bin/env bash
# Usage:  ./start.sh         start Candilon
#         ./start.sh demo    start Candilon and add the sample hospital file
set -euo pipefail
cd "$(dirname "$0")"
command -v docker >/dev/null || { echo "Docker is not installed. Install Docker Desktop first: https://www.docker.com/products/docker-desktop"; exit 1; }
docker info >/dev/null 2>&1 || { echo "Docker is installed but not running. Open Docker Desktop, wait until it says 'running', then try again."; exit 1; }
mkdir -p secrets
[ -s secrets/db_password.txt ] || (openssl rand -hex 24 2>/dev/null || date +%s%N | sha256sum | cut -c1-48) | tr -d '\n' > secrets/db_password.txt
[ -s secrets/pseudo_salt.txt ] || (openssl rand -hex 32 2>/dev/null || date +%s%N | sha256sum | cut -c1-64) | tr -d '\n' > secrets/pseudo_salt.txt
chmod 600 secrets/*.txt
bash arx/get_arx.sh || exit 1
echo "Starting Candilon (first run builds the images and can take 5-10 minutes)..."
for svc in privacy api arx; do
  for try in 1 2 3 4 5; do
    if docker compose build "$svc"; then break; fi
    [ "$try" = 5 ] && { echo "Building $svc failed 5 times. Check your internet connection and run ./start.sh again (finished downloads are cached)."; exit 1; }
    echo "Build of $svc failed (attempt $try of 5). Retrying; finished downloads are cached..."
  done
done
docker compose up -d --wait
if [ "${1:-}" = "demo" ]; then docker compose --profile demo run --rm seed; fi
PORT=$(grep -E '^CANDILON_PORT=' .env | cut -d= -f2); PORT=${PORT:-8080}
echo; ./status.sh; echo
echo "Candilon is ready. Open: http://localhost:${PORT}"
(command -v open >/dev/null && open "http://localhost:${PORT}") || (command -v xdg-open >/dev/null && xdg-open "http://localhost:${PORT}") || true
