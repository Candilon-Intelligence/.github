"""Founder-side licence tool (runs inside the api image via ./license.sh). Keep license/private.pem SECRET and OFF customer machines.
  keygen                                   create signing key (license/private.pem) + config/license_public.pem
  issue --customer NAME [--days 365] [--grace 14] [--plan pilot]   -> license/<name>.license.json
  show FILE                                print and verify a licence
"""
import argparse, base64, datetime, json, pathlib, re, sys
sys.path.insert(0, "/app")
from licensing import canonical
from cryptography.hazmat.primitives import serialization as S
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

LIC, CFG = pathlib.Path("/license"), pathlib.Path("/candilon/config")
ap = argparse.ArgumentParser()
sub = ap.add_subparsers(dest="cmd", required=True)
sub.add_parser("keygen")
i = sub.add_parser("issue"); i.add_argument("--customer", required=True); i.add_argument("--days", type=int, default=365)
i.add_argument("--grace", type=int, default=14); i.add_argument("--plan", default="pilot")
sh = sub.add_parser("show"); sh.add_argument("file")
a = ap.parse_args()

if a.cmd == "keygen":
    if (LIC / "private.pem").exists():
        sys.exit("license/private.pem already exists. Refusing to overwrite (that would invalidate every issued licence).")
    k = Ed25519PrivateKey.generate()
    (LIC / "private.pem").write_bytes(k.private_bytes(S.Encoding.PEM, S.PrivateFormat.PKCS8, S.NoEncryption()))
    (CFG / "license_public.pem").write_bytes(k.public_key().public_bytes(S.Encoding.PEM, S.PublicFormat.SubjectPublicKeyInfo))
    print("Created license/private.pem (KEEP SECRET, back it up) and config/license_public.pem.")
elif a.cmd == "issue":
    k = S.load_pem_private_key((LIC / "private.pem").read_bytes(), None)
    today = datetime.date.today()
    d = {"customer": a.customer, "plan": a.plan, "issued": today.isoformat(), "expires": (today + datetime.timedelta(days=a.days)).isoformat(), "grace_days": a.grace}
    d["signature"] = base64.b64encode(k.sign(canonical(d))).decode()
    out = LIC / (re.sub(r"[^a-z0-9]+", "-", a.customer.lower()).strip("-") + ".license.json")
    out.write_text(json.dumps(d, indent=1))
    print(f"Issued {out.name}: valid until {d['expires']} (+{a.grace} days grace). Give it to the customer as config/license.json")
else:
    d = json.load(open(a.file))
    S.load_pem_public_key((CFG / "license_public.pem").read_bytes()).verify(base64.b64decode(d["signature"]), canonical(d))
    print(json.dumps({k: v for k, v in d.items() if k != "signature"}, indent=1), "\nSignature: VALID")
