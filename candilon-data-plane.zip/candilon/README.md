# Candilon: data-preparation stack

Upload -> Clean -> PII discovery -> De-identify -> ARX privacy analysis -> Quality -> Approval gate.
No models, router or RAG in this stack. Only approved data lands in `data/approved/`.

    ./start.sh          # start (see DEMO_GUIDE.md)
    ./start.sh demo     # also drops a messy 5,000-row sample hospital file into data/incoming/
    ./status.sh         # service health
    ./stop.sh

Open http://localhost:8080 (change CANDILON_PORT in .env).

Services: dashboard (nginx) · api (orchestrator, provenance chain, audit) · privacy (cleaner, PII, de-id, quality, reports)
Before/after evidence, masked previews and licensing: see LICENSING.md.
· arx (ARX 3.9.1 risk analysis) · database (PostgreSQL). Secrets are generated into `secrets/` by start.sh.

Tune behaviour in `config/privacy.yaml` (column hints, per-category actions) and `config/policies.yaml` (approval thresholds).
Outputs: `data/processing/<id>/` (cleaned.csv, deidentified.csv), `data/approved/`, `data/quarantine/`,
`reports/<id>.html` plus per-stage JSON under `reports/{pii,privacy,quality,verification,provenance}/`.
API: GET /status /reports /provenance /provenance/verify /audit /datasets /incoming; POST /ingest /clean /scan-pii /deidentify /privacy/analyze /quality/analyze /approve.
