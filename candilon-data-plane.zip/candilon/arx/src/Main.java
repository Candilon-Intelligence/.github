import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import org.deidentifier.arx.*;
import org.deidentifier.arx.ARXPopulationModel.Region;
import org.deidentifier.arx.risk.*;

import java.io.File;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** ARX privacy-analysis service. GET /analyze?path=<csv>&qi=a,b  ->  k, equivalence classes, uniqueness, re-identification risk. */
public class Main {
    public static void main(String[] args) throws Exception {
        HttpServer s = HttpServer.create(new InetSocketAddress(8080), 0);
        s.createContext("/health", x -> send(x, 200, "{\"status\":\"ok\"}"));
        s.createContext("/analyze", x -> {
            try { send(x, 200, analyze(query(x))); }
            catch (Throwable e) { send(x, 500, "{\"error\":\"" + String.valueOf(e).replace("\"", "'") + "\"}"); }
        });
        s.start();
    }

    static String analyze(Map<String, String> q) throws Exception {
        String path = q.get("path");
        if (path == null || !path.startsWith("/candilon/data/")) throw new IllegalArgumentException("invalid path");
        Data data = Data.create(new File(path), StandardCharsets.UTF_8, ',');
        String qi = q.getOrDefault("qi", "");
        for (String c : qi.split(",")) if (!c.isBlank()) data.getDefinition().setAttributeType(c.trim(), AttributeType.QUASI_IDENTIFYING_ATTRIBUTE);
        DataHandle h = data.getHandle();
        var ec = h.getStatistics().getEquivalenceClassStatistics();
        RiskEstimateBuilder rb = h.getRiskEstimator(ARXPopulationModel.create(Region.USA));
        RiskModelSampleRisks risks = rb.getSampleBasedReidentificationRisk();
        RiskModelSampleUniqueness uq = rb.getSampleBasedUniquenessRisk();
        return String.format(Locale.ROOT,
            "{\"records\":%d,\"quasi_identifiers\":\"%s\",\"k_anonymity\":%d,\"equivalence_classes\":%d,"
          + "\"avg_class_size\":%.3f,\"max_class_size\":%d,\"highest_reidentification_risk\":%.6f,"
          + "\"average_reidentification_risk\":%.6f,\"fraction_unique_records\":%.6f}",
            h.getNumRows(), qi, ec.getMinimalEquivalenceClassSize(), ec.getNumberOfEquivalenceClasses(),
            ec.getAverageEquivalenceClassSize(), ec.getMaximalEquivalenceClassSize(),
            risks.getHighestRisk(), risks.getAverageRisk(), uq.getFractionOfUniqueRecords());
    }

    static Map<String, String> query(HttpExchange x) throws Exception {
        Map<String, String> m = new HashMap<>();
        String raw = x.getRequestURI().getRawQuery();
        if (raw != null) for (String p : raw.split("&")) {
            String[] kv = p.split("=", 2);
            m.put(URLDecoder.decode(kv[0], "UTF-8"), kv.length > 1 ? URLDecoder.decode(kv[1], "UTF-8") : "");
        }
        return m;
    }

    static void send(HttpExchange x, int code, String body) throws java.io.IOException {
        byte[] b = body.getBytes(StandardCharsets.UTF_8);
        x.getResponseHeaders().add("Content-Type", "application/json");
        x.sendResponseHeaders(code, b.length);
        try (var o = x.getResponseBody()) { o.write(b); }
    }
}
