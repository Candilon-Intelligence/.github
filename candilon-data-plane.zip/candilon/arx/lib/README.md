Put the ARX library jar (libarx, any version 3.9.x) in this folder.
start.sh does this automatically via ../get_arx.sh. Manual option: download "ARX library" from
https://arx.deidentifier.org/downloads/ (or the release assets at https://github.com/arx-deidentifier/arx/releases)
and copy the .jar file here.
