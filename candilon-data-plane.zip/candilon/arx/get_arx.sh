#!/usr/bin/env bash
# Downloads the ARX library jar into arx/lib (it is not published on Maven Central).
cd "$(dirname "$0")"; mkdir -p lib
if ls lib/*.jar >/dev/null 2>&1; then echo "ARX library already present."; exit 0; fi
echo "Looking up the latest ARX library release on GitHub..."
URL=$(curl -fsSL https://api.github.com/repos/arx-deidentifier/arx/releases/latest 2>/dev/null \
  | grep -o '"browser_download_url": *"[^"]*"' | cut -d'"' -f4 | grep -i 'lib[^/]*\.jar$' | head -1 || true)
if [ -n "$URL" ]; then
  echo "Downloading $URL"
  if curl -fL "$URL" -o lib/libarx.jar && unzip -tq lib/libarx.jar >/dev/null 2>&1; then echo "ARX library downloaded."; exit 0; fi
  rm -f lib/libarx.jar
fi
cat <<MSG
Could not download the ARX library automatically.
Do this once by hand:
  1. Open https://arx.deidentifier.org/downloads/  (the "ARX library" / libarx .jar)
     or https://github.com/arx-deidentifier/arx/releases (look for a file with "lib" in its name and ending .jar)
  2. Copy that .jar into: $(pwd)/lib/
  3. Run ./start.sh again
MSG
exit 1
