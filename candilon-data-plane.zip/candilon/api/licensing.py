"""Offline-verifiable licence (Ed25519). Expired licence pauses NEW processing only;
existing data, reports and approved files always remain available. No remote wipe, no data leaves the site."""
import json, base64, datetime, pathlib
from cryptography.hazmat.primitives.serialization import load_pem_public_key

CFG = pathlib.Path("/candilon/config")
TRIAL_DAYS = 30


def canonical(d):
    return json.dumps({k: v for k, v in d.items() if k != "signature"}, sort_keys=True, separators=(",", ":")).encode()


def _s(state, can, msg, **kw):
    return {"state": state, "can_process": can, "message": msg, **kw}


def license_status(first_seen, today):
    lic_f, pub_f = CFG / "license.json", CFG / "license_public.pem"
    if lic_f.exists() and pub_f.exists():
        try:
            d = json.load(open(lic_f))
            load_pem_public_key(pub_f.read_bytes()).verify(base64.b64decode(d["signature"]), canonical(d))
            exp = datetime.date.fromisoformat(d["expires"])
        except Exception:
            return _s("invalid", False, "The licence file is invalid. New processing is paused. Contact Candilon.")
        left, grace = (exp - today).days, int(d.get("grace_days", 14))
        base = {"customer": d.get("customer"), "plan": d.get("plan"), "expires": d["expires"], "days_left": left}
        if left >= 0:
            return _s("active", True, f"Licensed to {d.get('customer')} until {exp}.", **base)
        if -left <= grace:
            return _s("grace", True, f"Licence expired on {exp}. New processing pauses in {grace + left} days. Existing results stay available. Please renew.", **base)
        return _s("expired", False, f"Licence expired on {exp}. New processing is paused. Your data, reports and approved files remain available. Contact Candilon to renew.", **base)
    left = TRIAL_DAYS - (today - first_seen).days
    if left > 0:
        return _s("trial", True, f"Trial: {left} days left.", days_left=left)
    return _s("expired", False, "Trial ended. New processing is paused. Your data, reports and approved files remain available. Contact Candilon for a licence.")
