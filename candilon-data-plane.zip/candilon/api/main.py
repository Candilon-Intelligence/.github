"""Candilon API: the single entry point. Orchestrates the data plane, enforces stage order,
and writes the provenance chain (V-TSAL) and audit log."""
import os, re, json, time, shutil, hashlib, pathlib, datetime
from contextlib import asynccontextmanager
import httpx, psycopg, yaml
from licensing import license_status
from psycopg.types.json import Jsonb
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel

DATA, REPORTS = pathlib.Path("/candilon/data"), pathlib.Path("/candilon/reports")
PRIV, ARX = os.getenv("PRIVACY_URL", "http://privacy:8000"), os.getenv("ARX_URL", "http://arx:8080")
DSN = (f"host={os.getenv('DATABASE_HOST', 'database')} port=5432 dbname=candilon user=candilon "
       f"password={open('/run/secrets/db_password').read().strip()}")
ORDER = ["ingest", "clean", "pii", "deid", "privacy", "quality", "approve"]
OUTFILE = {"clean": "cleaned.csv", "deid": "deidentified.csv", "pii": "pii_findings.json"}
DDL = """
create table if not exists datasets(id text primary key, filename text, sha256 text, created_at timestamptz default now());
create table if not exists stage_results(dataset_id text, stage text, status text, result jsonb, updated_at timestamptz default now(), primary key(dataset_id, stage));
create table if not exists provenance_records(id bigserial primary key, ts text, dataset_id text, stage text, actor text, input_ref text, output_ref text, output_hash text, prev_hash text, record_hash text);
create table if not exists kv(key text primary key, value text);
create table if not exists audit_events(id bigserial primary key, ts text, actor text, action text, dataset_id text, detail jsonb);
"""
def db():
    return psycopg.connect(DSN, autocommit=True)


def init():
    for _ in range(30):
        try:
            with db() as c:
                c.execute(DDL)
            return
        except Exception:
            time.sleep(2)
    raise RuntimeError("database unavailable")


@asynccontextmanager
async def lifespan(_app):
    init()
    yield


app = FastAPI(title="candilon-api", lifespan=lifespan)

now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")
jhash = lambda o: hashlib.sha256(json.dumps(o, sort_keys=True, default=str).encode()).hexdigest()


def fhash(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def audit(actor, action, ds, detail=None):
    with db() as c:
        c.execute("insert into audit_events(ts,actor,action,dataset_id,detail) values(%s,%s,%s,%s,%s)",
                  (now(), actor, action, ds, Jsonb(detail or {})))


def record(ds, stage, actor, inref, outref, ohash):
    with db() as c:
        row = c.execute("select record_hash from provenance_records order by id desc limit 1").fetchone()
        prev, ts = (row[0] if row else "GENESIS"), now()
        h = hashlib.sha256("|".join([prev, ds, stage, actor, inref, outref, ohash, ts]).encode()).hexdigest()
        c.execute("insert into provenance_records(ts,dataset_id,stage,actor,input_ref,output_ref,output_hash,prev_hash,record_hash) values(%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                  (ts, ds, stage, actor, inref, outref, ohash, prev, h))


def stages(ds):
    with db() as c:
        rows = c.execute("select stage,status,result,updated_at from stage_results where dataset_id=%s", (ds,)).fetchall()
    return {s: {"status": st, "result": r, "updated_at": str(u)} for s, st, r, u in rows}


def provenance(ds):
    with db() as c:
        rows = c.execute("select ts,stage,actor,input_ref,output_ref,output_hash,prev_hash,record_hash from provenance_records where dataset_id=%s order by id", (ds,)).fetchall()
    keys = ["ts", "stage", "actor", "input_ref", "output_ref", "output_hash", "prev_hash", "record_hash"]
    return [dict(zip(keys, r)) for r in rows]


def call(method, url, **kw):
    try:
        r = httpx.request(method, url, timeout=None, **kw)
    except httpx.HTTPError as e:
        raise HTTPException(502, f"{url} unreachable: {e}")
    if r.status_code >= 400:
        raise HTTPException(502, f"{url}: {r.text[:400]}")
    return r.json()


class StageReq(BaseModel):
    dataset_id: str = ""
    filename: str = ""
    approver: str = ""
    confirm: bool = False


def h_ingest(ds, st, req):
    src = DATA / "incoming" / pathlib.Path(req.filename).name
    if not src.is_file():
        raise HTTPException(404, f"{req.filename} not found in data/incoming")
    sha = fhash(src)
    ds = re.sub(r"[^a-z0-9]+", "-", src.stem.lower()).strip("-") + "-" + sha[:8]
    (DATA / "processing" / ds).mkdir(parents=True, exist_ok=True)
    json.dump({"filename": src.name, "sha256": sha}, open(DATA / "processing" / ds / "meta.json", "w"))
    with db() as c:
        c.execute("insert into datasets(id,filename,sha256) values(%s,%s,%s) on conflict do nothing", (ds, src.name, sha))
    return {"dataset_id": ds, "filename": src.name, "bytes": src.stat().st_size, "sha256": sha, "format": src.suffix.lower().lstrip(".")}


def lic():
    today = datetime.date.today()
    with db() as c:
        c.execute("insert into kv values('first_seen',%s) on conflict do nothing", (today.isoformat(),))
        first = datetime.date.fromisoformat(c.execute("select value from kv where key='first_seen'").fetchone()[0])
        row = c.execute("select value from kv where key='last_seen'").fetchone()
        eff = max(today, datetime.date.fromisoformat(row[0])) if row else today  # clock rollback does not extend the licence
        c.execute("insert into kv values('last_seen',%s) on conflict(key) do update set value=excluded.value", (eff.isoformat(),))
    return license_status(first, eff)


def h_privacy(ds, st, req):
    d = st["deid"]["result"]
    base = f"/candilon/data/processing/{ds}/"
    after = call("GET", f"{ARX}/analyze", params={"path": base + "deidentified.csv", "qi": ",".join(d["quasi_identifiers"])})
    qb = d.get("quasi_identifiers_before") or []
    before = call("GET", f"{ARX}/analyze", params={"path": base + "cleaned.csv", "qi": ",".join(qb)}) if qb else None
    extra = call("POST", f"{PRIV}/privacy-extra", json={"dataset_id": ds, "quasi_identifiers": d["quasi_identifiers"], "sensitive": d["sensitive"]})
    return {**after, **extra, "engine": "ARX", "before": before}


def h_approve(ds, st, req):
    pol = yaml.safe_load(open("/candilon/config/policies.yaml"))
    pv, q, d = st["privacy"]["result"], st["quality"]["result"], st["deid"]["result"]
    human = bool(req.approver.strip() and req.confirm) or not pol["require_human_approval"]
    rules = [
        ("k-anonymity", pv["k_anonymity"], f">= {pol['min_k']}", pv["k_anonymity"] >= pol["min_k"]),
        ("highest re-identification risk", pv["highest_reidentification_risk"], f"<= {pol['max_highest_reidentification_risk']}", pv["highest_reidentification_risk"] <= pol["max_highest_reidentification_risk"]),
        ("unique records", pv["fraction_unique_records"], f"<= {pol['max_fraction_unique_records']}", pv["fraction_unique_records"] <= pol["max_fraction_unique_records"]),
        ("residual PII findings", d["residual_pii_findings"], f"<= {pol['max_residual_pii_findings']}", d["residual_pii_findings"] <= pol["max_residual_pii_findings"]),
        ("utility score", q["utility_score"], f">= {pol['min_utility_score']}", q["utility_score"] >= pol["min_utility_score"]),
        ("human approval", req.approver or "none", "named approver + confirmation", human),
    ]
    checks = [dict(name=n, value=v, rule=r, passed=bool(p)) for n, v, r, p in rules]
    ok = all(c["passed"] for c in checks)
    res = {"decision": "approved" if ok else "rejected", "approver": req.approver, "checks": checks}
    if ok:
        src = DATA / "processing" / ds / "deidentified.csv"
        dst = DATA / "approved" / f"{ds}.csv"
        shutil.copy(src, dst)
        res["approved_file"] = dst.name
        json.dump({"dataset_id": ds, "approved_at": now(), "approver": req.approver, "sha256": fhash(dst), "checks": checks},
                  open(DATA / "approved" / f"{ds}.manifest.json", "w"), indent=1)
    return res


HANDLERS = {
    "ingest": h_ingest,
    "clean": lambda ds, st, r: call("POST", f"{PRIV}/clean", json={"dataset_id": ds}),
    "pii": lambda ds, st, r: call("POST", f"{PRIV}/scan-pii", json={"dataset_id": ds}),
    "deid": lambda ds, st, r: call("POST", f"{PRIV}/deidentify", json={"dataset_id": ds}),
    "privacy": h_privacy,
    "quality": lambda ds, st, r: call("POST", f"{PRIV}/quality", json={"dataset_id": ds}),
    "approve": h_approve,
}


def execute(stage, req):
    actor = req.approver or "ui"
    ds, st, i = req.dataset_id, {}, ORDER.index(stage)
    L = lic()
    if not L["can_process"]:
        audit(actor, f"{stage}.blocked_by_license", ds, {"state": L["state"]})
        raise HTTPException(402, L["message"])
    if stage != "ingest":
        st = stages(ds)
        prev = ORDER[i - 1]
        if st.get(prev, {}).get("status") != "complete":
            raise HTTPException(409, f"Run '{prev}' first.")
    try:
        result = HANDLERS[stage](ds, st, req)
    except HTTPException as e:
        audit(actor, f"{stage}.failed", ds, {"error": e.detail})
        raise
    ds = result.get("dataset_id", ds)
    status = "rejected" if result.get("decision") == "rejected" else "complete"
    with db() as c:
        c.execute("delete from stage_results where dataset_id=%s and stage = any(%s)", (ds, ORDER[i + 1:] + [stage]))
        c.execute("insert into stage_results(dataset_id,stage,status,result) values(%s,%s,%s,%s)", (ds, stage, status, Jsonb(result)))
    out = DATA / "processing" / ds / OUTFILE.get(stage, "-")
    if stage == "approve" and status == "complete":
        out = DATA / "approved" / f"{ds}.csv"
    record(ds, stage, actor, ORDER[i - 1] if i else req.filename, out.name if out.is_file() else f"{stage}-result",
           fhash(out) if out.is_file() else jhash(result))
    audit(actor, f"{stage}.{status}", ds)
    if stage != "ingest":
        call("POST", f"{PRIV}/report", json={"dataset_id": ds, "stages": {k: v["result"] for k, v in stages(ds).items()}, "provenance": provenance(ds)})
    return {"dataset_id": ds, "stage": stage, "status": status, "result": result}


for _stage, _path in [("ingest", "/ingest"), ("clean", "/clean"), ("pii", "/scan-pii"), ("deid", "/deidentify"),
                      ("privacy", "/privacy/analyze"), ("quality", "/quality/analyze"), ("approve", "/approve")]:
    def _mk(s):
        def handler(req: StageReq):
            return execute(s, req)
        handler.__name__ = f"run_{s}"
        return handler
    app.post(_path)(_mk(_stage))


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/upload")
async def upload(file: UploadFile = File(...)):
    name = pathlib.Path(file.filename).name
    with open(DATA / "incoming" / name, "wb") as f:
        while chunk := await file.read(1 << 20):
            f.write(chunk)
    audit("ui", "upload", "", {"filename": name})
    return {"filename": name}


@app.get("/incoming")
def incoming():
    return [p.name for p in sorted((DATA / "incoming").iterdir()) if p.is_file() and not p.name.startswith(".")]


@app.get("/datasets")
def datasets():
    with db() as c:
        return [{"id": i, "filename": f, "created_at": str(t)} for i, f, t in c.execute("select id,filename,created_at from datasets order by created_at desc").fetchall()]


@app.get("/status")
def status(dataset_id: str = ""):
    svc = {}
    for n, u in {"privacy": f"{PRIV}/health", "arx": f"{ARX}/health"}.items():
        try:
            svc[n] = "healthy" if httpx.get(u, timeout=2).status_code == 200 else "unhealthy"
        except Exception:
            svc[n] = "down"
    svc["database"], svc["api"] = "healthy", "healthy"
    return {"services": svc, "license": lic(), "stages": stages(dataset_id) if dataset_id else {}}


@app.get("/license")
def license_info():
    return lic()


@app.get("/preview")
def preview(dataset_id: str, n: int = 6, raw: bool = False):
    return call("GET", f"{PRIV}/preview", params={"dataset_id": dataset_id, "n": n, "raw": str(raw).lower()})


@app.get("/reports")
def reports():
    return sorted(p.name for p in REPORTS.glob("*.html"))


@app.get("/reports/{name}")
def report_file(name: str):
    p = REPORTS / pathlib.Path(name).name
    if not p.is_file():
        raise HTTPException(404, "report not found")
    return FileResponse(p)


@app.get("/provenance")
def prov(dataset_id: str):
    return provenance(dataset_id)


@app.get("/provenance/verify")
def verify():
    with db() as c:
        rows = c.execute("select ts,dataset_id,stage,actor,input_ref,output_ref,output_hash,prev_hash,record_hash,id from provenance_records order by id").fetchall()
    prev = "GENESIS"
    for r in rows:
        ts, ds, stg, act, i, o, oh, ph, rh, rid = r
        calc = hashlib.sha256("|".join([prev, ds, stg, act, i, o, oh, ts]).encode()).hexdigest()
        if ph != prev or calc != rh:
            return {"valid": False, "broken_at_record": rid}
        prev = rh
    return {"valid": True, "records": len(rows)}


@app.get("/audit")
def audit_log(limit: int = 200):
    with db() as c:
        rows = c.execute("select ts,actor,action,dataset_id,detail from audit_events order by id desc limit %s", (limit,)).fetchall()
    return [dict(zip(["ts", "actor", "action", "dataset_id", "detail"], r)) for r in rows]
