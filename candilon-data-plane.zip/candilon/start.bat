@echo off
REM Usage:  start.bat         start Candilon
REM         start.bat demo    start Candilon and add the sample hospital file
cd /d "%~dp0"
docker info >nul 2>&1
if errorlevel 1 (
  echo Docker is not running. Open Docker Desktop, wait until it says running, then try again.
  pause & exit /b 1
)
if not exist secrets mkdir secrets
if not exist secrets\db_password.txt powershell -NoProfile -Command "([guid]::NewGuid().ToString('N') + [guid]::NewGuid().ToString('N')) | Set-Content -NoNewline secrets\db_password.txt"
if not exist secrets\pseudo_salt.txt powershell -NoProfile -Command "([guid]::NewGuid().ToString('N') + [guid]::NewGuid().ToString('N')) | Set-Content -NoNewline secrets\pseudo_salt.txt"
if not exist arx\lib\*.jar (
  echo The ARX library jar is missing. Download it from https://arx.deidentifier.org/downloads/ into arx\lib and run again.
  pause & exit /b 1
)
echo Starting Candilon (first run builds the images and can take 5-10 minutes)...
docker compose up -d --build --wait
if errorlevel 1 ( echo Start failed. Run: docker compose logs & pause & exit /b 1 )
if /i "%1"=="demo" docker compose --profile demo run --rm seed
echo.
echo Candilon is ready. Opening http://localhost:8080
start http://localhost:8080
