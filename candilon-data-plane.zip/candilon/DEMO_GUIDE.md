# Candilon demo: how to run it

## One-time setup
Install **Docker Desktop** (Windows/Mac) or Docker Engine + Compose (Linux). Open it and wait until it says it is running.

## Start (3 steps)
1. Unzip the `candilon` folder anywhere.
2. Open a terminal in that folder and run:
   - Mac/Linux: `./start.sh demo`
   - Windows: double-click `start.bat`, or in a terminal `start.bat demo`
3. Your browser opens at **http://localhost:8080**. (First run builds images: 5-10 minutes. Later starts take seconds.)

`demo` adds a sample hospital file (`demo_patients.csv`, 5,000+ rows). Leave `demo` off to start empty and use your own data.

## Run the demo in the UI
1. Pick `demo_patients.csv` in the dropdown (or choose your own file and click **Upload file**).
2. Click **Run next** repeatedly. It walks through: Ingest, Clean, PII scan, De-identify, Privacy analysis, Quality, Approve.
3. At the last step type an approver name, tick the confirmation box, then click **Approve data**.
4. Look at: results panel (right), provenance chain (right, bottom), **Open full report**.
5. Approved data appears in `data/approved/`.

Suggested talking points: after PII scan show the findings count and embedded PII in notes; after de-identify show dropped
columns and 0 residual findings; after privacy show k-anonymity; at approval show each policy check passing;
finish on the provenance chain ("Chain verified").

## Between demos
- Stop: `./stop.sh` (or `stop.bat`). Data is kept.
- Wipe everything and start fresh: `./reset.sh`.
- Health check: `./status.sh`.

## If something goes wrong
| Symptom | Fix |
|---|---|
| "Docker is not running" | Open Docker Desktop and wait for it to finish starting. |
| Port 8080 already used | Edit `.env`, set `CANDILON_PORT=8090`, run start again, open that port. |
| Page won't load | `docker compose ps` should show every service healthy. See `docker compose logs api`. |
| Privacy step fails | `docker compose logs arx`. Send me the error and I will fix it. |
| Approve shows "rejected" | Open the failed check in the results panel. Thresholds live in `config/policies.yaml`. |
| Changed a config file | `docker compose restart privacy api`, then re-run the stage. |

## Running on an 8 GB laptop (e.g. ThinkPad T480s)
- Linux (Ubuntu): best option, Docker uses almost no overhead.
- Windows: install Docker Desktop with WSL2, then create `C:\Users\<you>\.wslconfig` containing
  `[wsl2]` / `memory=4GB` / `processors=4` and run `wsl --shutdown` once. This stops Docker taking all your RAM.
- The stack idles around 1 GB. The 5,000-row demo is light. For 1M+ rows raise the limit or process in batches.
- ARX heap defaults to 1 GB; change `JAVA_OPTS` for the `arx` service in `compose.yaml` if needed.

## Running on Google Colab (no Docker)
See `colab/` and `Candilon_Colab.ipynb`: upload the zip to My Drive, open the notebook, run cells 1 to 4.
